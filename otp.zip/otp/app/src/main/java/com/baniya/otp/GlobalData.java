package com.baniya.otp;

/**
 * Created by Vidhi on 05-10-2018.
 */

class GlobalData {
}
