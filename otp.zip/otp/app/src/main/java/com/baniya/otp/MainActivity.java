package com.baniya.otp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText ed,ed2,ed3,ed4;
    TextView tv;
    String otp_generated;
    Button verify;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed= (EditText) findViewById(R.id.ed1);
        ed2= (EditText) findViewById(R.id.ed2);
        ed3= (EditText) findViewById(R.id.ed3);
        ed4= (EditText) findViewById(R.id.ed4);
        tv= (TextView) findViewById(R.id.tv);
        verify= (Button) findViewById(R.id.verify);
        SmsReceiver.bindListener(new SmsListener() {
            @Override
            public void messageReceived(String messageText) {

                ed.setText(""+messageText.charAt(0));
                ed2.setText(""+messageText.charAt(1));
                ed3.setText(""+messageText.charAt(2));
                ed4.setText(""+messageText.charAt(3));

                verify.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent i=new Intent(MainActivity.this,pg2.class);
                        startActivity(i);
                    }
                });
            }
        });
    }
}
