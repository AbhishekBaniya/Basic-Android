package com.baniya.otp;

/**
 * Created by Vidhi on 05-10-2018.
 */

public interface SmsListener {
    public void messageReceived(String messageText);
}
