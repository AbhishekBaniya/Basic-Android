package com.baniya.otp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class pg2 extends AppCompatActivity {
    TextView sucess;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pg2);
        sucess.findViewById(R.id.sucess);

    }
}
